import static org.junit.Assert.*;

public class GuiControllerTest {
}